import math

class Optimizer:
    def __init__(self):
        # Default weights (used if not in state)
        self.default_w1 = 1.0
        self.default_w2 = 0.5
        self.default_w3 = 5.0

    def calculate_cost(self, y_ac, y_ref, metrics, state=None):
        w1 = self.default_w1
        w2 = self.default_w2
        w3 = self.default_w3
        
        if state:
            w1 = float(state.get('opt_w1', w1))
            w2 = float(state.get('opt_w2', w2))
            w3 = float(state.get('opt_w3', w3))

        error = abs(y_ac - y_ref)
        waste = metrics.get('resource_waste', 0.0)
        is_viol = 1.0 if y_ac > y_ref else 0.0
        
        J = w1 * error + w2 * waste + w3 * is_viol
        return J

    def update_weights(self, metrics, state):
        """
        Adaptive Weight Tuning using PI (Proportional-Integral) Logic.
        Persists state to the 'state' dictionary.
        """
        # Load state
        w1 = float(state.get('opt_w1', self.default_w1))
        w2 = float(state.get('opt_w2', self.default_w2))
        w3 = float(state.get('opt_w3', self.default_w3))
        int_viol_err = float(state.get('opt_int_viol_err', 0.0))
        int_waste_err = float(state.get('opt_int_waste_err', 0.0))
        stable_count = int(state.get('opt_stable_count', 0))
        tense_count = int(state.get('opt_tense_count', 0))

        viol_rate = metrics.get('slo_violation_rate', 0.0)
        waste_rate = metrics.get('resource_waste_rate', 0.0)
        
        # 1. Adapt w3 (SLO Penalty)
        w3_step_inc = float(state.get('opt_w3_step_inc', 50.0))
        w3_step_dec = float(state.get('opt_w3_step_dec', 0.95))
        w3_min = float(state.get('opt_w3_min', 5.0))
        w3_max = float(state.get('opt_w3_max', 200.0))
        
        if viol_rate > 0.0:
            w3 = w3_min + (viol_rate * w3_step_inc) + (int_viol_err * 10.0)
        else:
            int_viol_err *= 0.9
            w3 = max(w3_min, w3 * w3_step_dec)

        waste_stable_thr = float(state.get('opt_waste_stable_thr', 0.05))
        waste_tense_thr = float(state.get('opt_waste_tense_thr', 0.2))
        viol_tense_thr = float(state.get('opt_viol_tense_thr', 0.1))
        if viol_rate == 0.0 and waste_rate < waste_stable_thr:
            stable_count += 1
            tense_count = 0
        elif viol_rate > viol_tense_thr or waste_rate > waste_tense_thr:
            tense_count += 1
            stable_count = 0
        else:
            stable_count = max(0, stable_count - 1)
            tense_count = max(0, tense_count - 1)

        stable_thr = int(state.get('opt_stable_thr', 3))
        if stable_count >= stable_thr:
            int_viol_err = 0.0
            int_waste_err *= 0.5
            w3_relax_mul = float(state.get('opt_w3_relax_mul', 0.7))
            w2_relax_mul = float(state.get('opt_w2_relax_mul', 0.9))
            w3 = max(w3_min, w3 * w3_relax_mul)
            w2 = max(w2_min, w2 * w2_relax_mul)
            
        # 2. Adapt w2 (Waste Penalty)
        w2_step_inc = float(state.get('opt_w2_step_inc', 10.0))
        w2_step_dec = float(state.get('opt_w2_step_dec', 0.98))
        w2_min = float(state.get('opt_w2_min', 0.5))
        w2_max = float(state.get('opt_w2_max', 50.0))
        
        waste_base = float(state.get('opt_waste_err_base', 0.1))
        waste_cap = float(state.get('opt_waste_err_cap', 0.5))
        int_cap = float(state.get('opt_int_waste_cap', 5.0))
        int_decay = float(state.get('opt_int_decay', 0.9))
        viol_int_gain = float(state.get('opt_viol_int_gain', 10.0))
        waste_err = max(0.0, waste_rate - waste_base)
        if waste_err <= waste_cap:
            int_waste_err += waste_err
        int_waste_err = min(int_cap, max(0.0, int_waste_err))
        
        if waste_err > 0.0:
            w2_int_gain = float(state.get('opt_w2_int_gain', 2.0))
            w2 = w2_min + (waste_err * w2_step_inc) + (int_waste_err * w2_int_gain)
        else:
            int_waste_err *= int_decay
            w2 = max(w2_min, w2 * w2_step_dec)
            
        # Limit weights
        w3 = min(w3, w3_max)
        w2 = min(w2, w2_max)
        
        # Save state
        state['opt_w1'] = w1
        state['opt_w2'] = w2
        state['opt_w3'] = w3
        state['opt_int_viol_err'] = int_viol_err
        state['opt_int_waste_err'] = int_waste_err
        state['opt_stable_count'] = stable_count
        state['opt_tense_count'] = tense_count
        
        return {'w1': w1, 'w2': w2, 'w3': w3}

    def allocate(self, prev_u, price, eta=0.05, gamma=0.1, lower=0.0, upper=1.0):
        grad = price
        u_new = prev_u - eta * (grad + gamma * prev_u)
        if u_new < lower:
            u_new = lower
        if u_new > upper:
            u_new = upper
        return u_new

    def optimize_u(self, prev_u, pred_upper, slo_limit, price, eta=0.05, gamma=0.1, risk_comp=None, ku=None, risks=None, tau=1.0, ref_latency=None, state=None):
        """
        Gradient Descent Step for:
        min J(u) + (gamma/2)*||u||^2
        
        J = w1 * TrackingError + w2 * Waste + w3 * Risk + PricePenalty
        
        Args:
            ref_latency: Reference latency from trajectory generator (r_i)
        """
        # Load adaptive weights
        w1 = self.default_w1
        w2 = self.default_w2
        w3 = self.default_w3
        if state:
            w1 = float(state.get('opt_w1', w1))
            w2 = float(state.get('opt_w2', w2))
            w3 = float(state.get('opt_w3', w3))

        # 1. Risk Gradient (Risk of violating SLO)
        base_risk = max(0.0, (pred_upper - slo_limit) / max(1.0, slo_limit))
        soft_risk = base_risk
        
        # Softmax aggregation for risk vector
        if isinstance(risks, dict):
            vals = []
            for k in ('latency', 'timeout', 'error', 'memory'):
                v = float(risks.get(k, 0.0))
                vals.append(v)
            
            # Log-Sum-Exp Smooth Max
            mx = max(vals) if vals else 0.0
            if tau <= 0.0: tau = 1.0
            s = 0.0
            for v in vals:
                s += pow(2.718281828, (v - mx) / tau)
            if s > 0.0:
                soft_risk = mx + tau * math.log(s)
            else:
                soft_risk = mx

        if isinstance(risk_comp, (int, float)):
            # If composite risk is provided directly (legacy)
            soft_risk = float(risk_comp)
            
        # d(Risk)/du approx -ku * Risk (assuming u reduces risk)
        grad_risk = -1.0 * soft_risk
        if isinstance(ku, (int, float)):
            grad_risk = -float(ku) * soft_risk
            
        # 2. Waste Gradient (Resource Usage)
        # J_waste = u^2 or just u. Let's assume J_waste ~ u (linear cost) or u^2.
        # Here we use prev_u as gradient of (1/2)u^2, or 1.0 for linear.
        # Implementation uses prev_u, implying Waste ~ u^2/2
        grad_waste = prev_u 
        
        # 3. Tracking Error Gradient (New: Align with J(ti, y_ref, y_act))
        # J_track = (y_pred - y_ref)^2
        # d(J_track)/du = 2 * (y_pred - y_ref) * dy_pred/du
        # Approx dy_pred/du ~ -k (latency drops as u increases)
        grad_track = 0.0
        if ref_latency is not None:
            # y_pred is approx pred_upper (conservative) or we can estimate mean. 
            # Let's use pred_upper for safety.
            diff = pred_upper - ref_latency
            # If diff > 0 (too slow), we need more u -> grad should be negative.
            # If diff < 0 (too fast), we can reduce u -> grad should be positive.
            # grad = 2 * diff * (-1)
            grad_track = -1.0 * diff
        
        # Total Gradient
        # grad J = w1 * grad_track + w2 * grad_waste + w3 * grad_risk + price
        # Price Normalization Factor
        price_norm = 100.0
        if state:
             price_norm = float(state.get('opt_price_norm', 100.0))
        
        grad = w1 * grad_track + w3 * grad_risk + w2 * grad_waste + (price / price_norm)
        
        # Update Step with Regularization (gamma * u)
        # u_new = u - eta * (grad + gamma * u)
        step = eta * (grad + gamma * prev_u)
        u_new = prev_u - step
        
        # Projection to Feasible Set U (Box constraints [0, 1])
        lower = 0.0
        upper = 1.0
        if u_new < lower: u_new = lower
        if u_new > upper: u_new = upper
        
        return u_new
    
    def tune_params_by_price(self, price, eta_base, gamma_base, bands=None, state=None):
        """
        Adjust learning rate (eta) and regularization (gamma) based on price bands.
        """
        eta = float(eta_base)
        gamma = float(gamma_base)
        
        if isinstance(bands, list):
            for b in bands:
                lo = float(b.get('lo', 0.0))
                hi = float(b.get('hi', lo))
                e = float(b.get('eta_mul', 1.0))
                g = float(b.get('gamma_mul', 1.0))
                if price >= lo and price < hi:
                    eta = eta_base * e
                    gamma = gamma_base * g
                    break
        else:
            price_high = float(state.get('opt_price_high', 200.0)) if isinstance(state, dict) else 200.0
            price_med = float(state.get('opt_price_med', 50.0)) if isinstance(state, dict) else 50.0
            eta_high_mul = float(state.get('opt_eta_high_mul', 0.5)) if isinstance(state, dict) else 0.5
            gamma_high_mul = float(state.get('opt_gamma_high_mul', 1.5)) if isinstance(state, dict) else 1.5
            eta_med_mul = float(state.get('opt_eta_med_mul', 0.8)) if isinstance(state, dict) else 0.8
            gamma_med_mul = float(state.get('opt_gamma_med_mul', 1.2)) if isinstance(state, dict) else 1.2
            if price >= price_high:
                eta = eta_base * eta_high_mul
                gamma = gamma_base * gamma_high_mul
            elif price >= price_med:
                eta = eta_base * eta_med_mul
                gamma = gamma_base * gamma_med_mul
        return eta, gamma
